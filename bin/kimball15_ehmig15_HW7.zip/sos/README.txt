To Install the Delaney-Ehmig Hyper-Optimized HW6 Scheduler:
1. Ensure your SOS has the getRandomProcess() method, or copy it over.
2. Copy the getMoreRandomProcess() method over.
3. Copy the SCHEDULING_IMPROVEMENT_FACTOR constant over.
4. Replace your scheduling call with a call to getMoreRandomProcess().
5. Success!

If you have any issues, feel free to contact us.

